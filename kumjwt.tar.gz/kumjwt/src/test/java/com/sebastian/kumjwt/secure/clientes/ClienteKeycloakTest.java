package com.sebastian.kumjwt.secure.clientes;

import org.assertj.core.api.Assertions;
import org.junit.Test;

/**
 * test para la clase {@link ClienteKeycloak}.
 * 
 * @author Sebastian Avila A.
 *
 */
public class ClienteKeycloakTest {
  @Test
  public void tokenObtenidoConDatosCorrectos() {
    Assertions.assertThat(ClienteKeycloak.obtenerToken("sebastian", "elias")).isNotNull()
        .isNotEmpty();
  }
}
